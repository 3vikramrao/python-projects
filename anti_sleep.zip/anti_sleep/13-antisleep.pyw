import pyautogui
import time
import threading
import ctypes
import random
import tkinter as tk
from tkinter import ttk
import keyboard
import math

# --- CONFIG ---
IDLE_THRESHOLD = 60

running = False
last_mouse_pos = pyautogui.position()
last_activity_time = time.time()
next_interval = 25
remaining_time = 25

# --- Windows API ---
ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001
ES_DISPLAY_REQUIRED = 0x00000002


def prevent_sleep():
    ctypes.windll.kernel32.SetThreadExecutionState(
        ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
    )


# --- Track activity ---
def track_activity():
    global last_mouse_pos, last_activity_time

    while True:
        pos = pyautogui.position()
        if pos != last_mouse_pos:
            last_mouse_pos = pos
            last_activity_time = time.time()
        time.sleep(2)


# --- Smart keep awake ---
def keep_awake():
    global running, next_interval, remaining_time

    while True:

        next_interval = random.randint(15, 25)
        remaining_time = next_interval

        while remaining_time > 0:
            time.sleep(1)

            if running:
                remaining_time -= 1

        if running:
            idle = time.time() - last_activity_time

            if idle > IDLE_THRESHOLD:
                try:
                    prevent_sleep()

                    # Random movement
                    dx = random.randint(-3, 3)
                    dy = random.randint(-3, 3)
                    pyautogui.moveRel(dx, dy, duration=0.2)

                    # Random key
                    if random.random() > 0.5:
                        pyautogui.press('shift')

                except Exception as e:
                    print("Error:", e)


# --- GUI ---
def start_gui():
    global running

    root = tk.Tk()
    root.title("Anti-Sleep Bot")

    root.geometry("260x340")
    root.attributes('-topmost', True)

    label = tk.Label(root, text="❎ Stopped", font=("Arial", 12))  #❌
    label.pack(pady=10)

    canvas = tk.Canvas(root, width=240, height=240, bg="white", highlightthickness=0)
    canvas.pack(pady=5)

    timer_text = canvas.create_text(
        120,
        80,
        text="00:00",
        font=("Consolas", 18, "bold")
    )

    snake_segments = []
    snake_length = 30
    snake_angle = 0

    for i in range(snake_length):
        seg = canvas.create_oval(
            0, 0, 0, 0,
            fill="green",
            outline=""
        )
        snake_segments.append(seg)


    def animate_snake():
        nonlocal snake_angle

        if not running:
            for seg in snake_segments:
                canvas.itemconfig(seg, state="hidden")
            
            root.after(50, animate_snake)
            return
        percentage = remaining_time / max(next_interval, 1)

        visible_segments = max(
            1,
            int(snake_length * remaining_time / max(next_interval, 1))
        )

        # Continuous vertical motion
        PERIMETER = 2 * (240 + 240)

        position = (time.time() * 50) % PERIMETER

        for i, seg in enumerate(snake_segments):
            
            if i >= visible_segments:
                    canvas.itemconfig(seg, state="hidden")
                    continue

            canvas.itemconfig(seg, state="normal")
            p = (position - i * 8) % PERIMETER

            if p < 240:                     # Left side
                x = 20
                y = p

            elif p < 480:                   # Bottom
                x = 20 + (p - 240)
                y = 220 

            elif p < 720:                   # Right side
                x = 220
                y = 220 -(p -480)

            else:                           # Top
                x = 220 -(p - 720)
                y = 20

            percentage = remaining_time / max(next_interval, 1)

            if percentage > 0.5:
                color = "limegreen"
            elif percentage > 0.25:
                color = "orange"
            else:
                color = "red"

            if i == 0:
                canvas.itemconfig(seg, fill="darkgreen")
            else:
                canvas.itemconfig(seg, fill=color)
            size = 4

            canvas.coords(
                seg,
                x - size,
                y - size,
                x + size,
                y + size
            )

        root.after(50, animate_snake)

    def toggle():
        global running

        if not running:
            running = True
            label.config(text="✅ Running")
            btn_toggle.config(text="Stop")
            #canvas.itemconfig(circle, outline="white")
            #canvas.itemconfig(arc, outline="lime")
        else:
            running = False
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
            label.config(text="❎ Stopped")
            btn_toggle.config(text="Start")
            #canvas.itemconfig(circle, outline="red")
            #canvas.itemconfig(arc, outline="red")

    btn_toggle = tk.Button(
        root,
        text="Start",
        width=10,
        command=toggle
    )

    canvas.create_window(
        120, 130,
        window=btn_toggle
    )

    progress_value = 0

    def update_progress():

        display_time = remaining_time if running else 0

        minutes = remaining_time // 60
        seconds = remaining_time % 60

        canvas.itemconfig(
            timer_text,
            text=f"{minutes:02d}:{seconds:02d}"
        )

        root.after(500, update_progress)

    animate_snake()   
    update_progress()   
    root.mainloop()


# --- Hotkeys ---
keyboard.add_hotkey("ctrl+alt+s", lambda: print("Hotkey Start") or globals().update(running=True))
keyboard.add_hotkey("ctrl+alt+x", lambda: print("Hotkey Stop") or globals().update(running=False))

# --- Threads ---
threading.Thread(target=track_activity, daemon=True).start()
threading.Thread(target=keep_awake, daemon=True).start()

# --- Launch GUI ---
start_gui()
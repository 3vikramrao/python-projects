import pyautogui
import time
import threading
import ctypes
import random
import tkinter as tk
from tkinter import ttk
import keyboard

# --- CONFIG ---
IDLE_THRESHOLD = 60

running = False
last_mouse_pos = pyautogui.position()
last_activity_time = time.time()
next_interval = 25
remaining_time = 25

# --- Windows API ---
ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001
ES_DISPLAY_REQUIRED = 0x00000002


def prevent_sleep():
    ctypes.windll.kernel32.SetThreadExecutionState(
        ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
    )


# --- Track activity ---
def track_activity():
    global last_mouse_pos, last_activity_time

    while True:
        pos = pyautogui.position()
        if pos != last_mouse_pos:
            last_mouse_pos = pos
            last_activity_time = time.time()
        time.sleep(2)


# --- Smart keep awake ---
def keep_awake():
    global running, next_interval, remaining_time

    while True:

        next_interval = random.randint(15, 25)
        remaining_time = next_interval

        while remaining_time > 0:
            time.sleep(1)

            if running:
                remaining_time -= 1

        if running:
            idle = time.time() - last_activity_time

            if idle > IDLE_THRESHOLD:
                try:
                    prevent_sleep()

                    # Random movement
                    dx = random.randint(-3, 3)
                    dy = random.randint(-3, 3)
                    pyautogui.moveRel(dx, dy, duration=0.2)

                    # Random key
                    if random.random() > 0.5:
                        pyautogui.press('shift')

                except Exception as e:
                    print("Error:", e)


# --- GUI ---
def start_gui():
    global running

    root = tk.Tk()
    root.title("Anti-Sleep Bot")

    root.geometry("220x170")
    root.attributes('-topmost', True)

    label = tk.Label(root, text="❎ Stopped", font=("Arial", 12))  #❌
    label.pack(pady=10)
    timer_label = tk.Label(
        root,
        text="00:00",
        font=("Consolas", 15, "bold")
    )
    timer_label.pack()

    progress = ttk.Progressbar(
        root,
        orient="horizontal",
        length=180,
        mode="determinate",
        maximum=100
    )
    progress.pack(pady=5)

    def toggle():
        global running

        if not running:
            running = True
            label.config(text="✅ Running")
            btn_toggle.config(text="Stop")
        else:
            running = False
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
            label.config(text="❎ Stopped")
            btn_toggle.config(text="Start")

    btn_toggle = tk.Button(
        root,
        text="Start",
        width=7,
        font=("Arial", 10, "bold"),
        command=toggle
    )
    btn_toggle.pack(pady=5)

    progress_value = 0

    def update_progress():
        if running:

            progress["maximum"] = max(next_interval, 1)
            progress["value"] = max(0, remaining_time)

            minutes = remaining_time // 60
            seconds = remaining_time % 60

            timer_label.config(
                text=f"{minutes:02d}:{seconds:02d}"
            )

        else:
            progress["maximum"] = 100
            progress["value"] = 0
            timer_label.config(
                text="00:00"
            )

        root.after(500, update_progress)
        
    update_progress()   
    root.mainloop()


# --- Hotkeys ---
keyboard.add_hotkey("ctrl+alt+s", lambda: print("Hotkey Start") or globals().update(running=True))
keyboard.add_hotkey("ctrl+alt+x", lambda: print("Hotkey Stop") or globals().update(running=False))

# --- Threads ---
threading.Thread(target=track_activity, daemon=True).start()
threading.Thread(target=keep_awake, daemon=True).start()

# --- Launch GUI ---
start_gui()
import pyautogui
import time
import threading
import tkinter as tk

# --- Background task (keeps system active) ---
def keep_awake():
    while True:
        pyautogui.press('shift')  # harmless key
        time.sleep(30)

# --- UI Window ---
def start_ui():
    root = tk.Tk()
    root.title("Anti-Sleep Bot")

    # Small window size
    root.geometry("200x80")
    root.attributes('-topmost', True)  # Always on top

    label = tk.Label(root, text="✅ Running...", font=("Arial", 12))
    label.pack(pady=10)

    def stop():
        root.destroy()
        print("Stopped manually")
        exit()

    btn = tk.Button(root, text="Stop", command=stop)
    btn.pack()

    root.mainloop()

# --- Run both together ---
threading.Thread(target=keep_awake, daemon=True).start()
start_ui()

import pyautogui
import time
import threading
import tkinter as tk

INTERVAL = 30  # seconds between activity

# Shared countdown variable
countdown = INTERVAL

# --- Background task ---
def keep_awake():
    global countdown
    while True:
        for i in range(INTERVAL, 0, -1):
            countdown = i
            time.sleep(1)

        pyautogui.press('shift')  # simulate activity
        countdown = INTERVAL


# --- UI ---

def start_ui():
    root = tk.Tk()
    root.title("Anti-Sleep Bot")
    root.geometry("220x120")
    root.attributes('-topmost', True)

    status_label = tk.Label(root, text="RUNNING", font=("Arial", 14, "bold"), width=15)
    status_label.pack(pady=5)

    timer_label = tk.Label(root, text="", font=("Arial", 12))
    timer_label.pack()

    colors = ["#3498db", "#5dade2"]  # two shades of blue
    idx = 0

    def update_ui():
        nonlocal idx

        status_label.config(bg=colors[idx], fg="white")
        idx = 1 - idx  # toggle colors

        timer_label.config(text=f"Next activity in: {countdown}s")

        root.after(500, update_ui)

    def stop():
        root.destroy()
        exit()

    tk.Button(root, text="Stop", command=stop).pack(pady=8)

    update_ui()
    root.mainloop()

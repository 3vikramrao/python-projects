import pyautogui
import time
import threading
import ctypes
import random
import tkinter as tk
from tkinter import ttk
import keyboard
import math

# --- CONFIG ---
IDLE_THRESHOLD = 60

running = False
last_mouse_pos = pyautogui.position()
last_activity_time = time.time()
next_interval = 25
remaining_time = 25

# --- Windows API ---
ES_CONTINUOUS = 0x80000000
ES_SYSTEM_REQUIRED = 0x00000001
ES_DISPLAY_REQUIRED = 0x00000002


def prevent_sleep():
    ctypes.windll.kernel32.SetThreadExecutionState(
        ES_CONTINUOUS | ES_SYSTEM_REQUIRED | ES_DISPLAY_REQUIRED
    )


# --- Track activity ---
def track_activity():
    global last_mouse_pos, last_activity_time

    while True:
        pos = pyautogui.position()
        if pos != last_mouse_pos:
            last_mouse_pos = pos
            last_activity_time = time.time()
        time.sleep(2)


# --- Smart keep awake ---
def keep_awake():
    global running, next_interval, remaining_time

    while True:

        next_interval = random.randint(15, 25)
        remaining_time = next_interval

        while remaining_time > 0:
            time.sleep(1)

            if running:
                remaining_time -= 1

        if running:
            idle = time.time() - last_activity_time

            if idle > IDLE_THRESHOLD:
                try:
                    prevent_sleep()

                    # Random movement
                    dx = random.randint(-3, 3)
                    dy = random.randint(-3, 3)
                    pyautogui.moveRel(dx, dy, duration=0.2)

                    # Random key
                    if random.random() > 0.5:
                        pyautogui.press('shift')

                except Exception as e:
                    print("Error:", e)


# --- GUI ---
def start_gui():
    global running

    root = tk.Tk()
    root.title("Anti-Sleep Bot")

    root.geometry("260x340")
    root.attributes('-topmost', True)

    label = tk.Label(root, text="❎ Stopped", font=("Arial", 12))  #❌
    label.pack(pady=10)

    canvas = tk.Canvas(root, width=240, height=240, bg="white", highlightthickness=0)
    canvas.pack(pady=5)

    timer_text = canvas.create_text(
        120,
        80,
        text="00:00",
        font=("Consolas", 18, "bold")
    )

    atom_particles = []
    particle_count = 24
    orbit_angle = 0

    # nucleus
    canvas.create_oval(
        112, 112,
        128, 128,
        fill="gold",
        outline="orange",
        width=2
    )

    for _ in range(particle_count):
        particle = canvas.create_oval(
            0, 0,
            0, 0,
            fill="cyan",
            outline=""
        )
        atom_particles.append(particle)

    def animate_atom():
        nonlocal orbit_angle

        center_x = 120
        center_y = 120

        orbit_angle += 0.05

        if not running:
            for p in atom_particles:
                canvas.itemconfig(p, state="hidden")

            root.after(30, animate_atom)
            return

        percentage = remaining_time / max(next_interval, 1)

        visible_particles = max(
            1,
            int(
                particle_count *
                percentage
            )
        )

        canvas.delete("orbit")

        canvas.create_oval(
            50, 50,
            190, 190,
            outline="#BBBBBB",
            tags="orbit"
        )

        canvas.create_oval(
            50, 85,
            190, 155,
            outline="#999999",
            tags="orbit"
        )

        canvas.create_oval(
            85, 50,
            155, 190,
            outline="#999999",
            tags="orbit"
        )

        for i, particle in enumerate(atom_particles):

            if i >= visible_particles:
                canvas.itemconfig(
                    particle,
                    state="hidden"
                )
                continue

            canvas.itemconfig(
                particle,
                state="normal"
            )

            angle = orbit_angle + i * (
                2 * math.pi / particle_count
            )

            orbit = i % 3

            radius = 70

            if orbit == 0:
                x = center_x + radius * math.cos(angle)
                y = center_y + radius * math.sin(angle)

            elif orbit == 1:
                x = center_x + radius * math.cos(angle)
                y = center_y + radius * math.sin(angle) * 0.4

            else:
                x = center_x + radius * math.sin(angle) * 0.4
                y = center_y + radius * math.cos(angle)

            if percentage > 0.5:
                color = "cyan"
            elif percentage > 0.25:
                color = "orange"
            else:
                color = "red"

            canvas.itemconfig(
                particle,
                fill=color
            )

            size = 4

            canvas.coords(
                particle,
                x - size,
                y - size,
                x + size,
                y + size
            )

        root.after(30, animate_atom)
    

    def toggle():
        global running

        if not running:
            running = True
            label.config(text="✅ Running")
            btn_toggle.config(text="Stop")
            #canvas.itemconfig(circle, outline="white")
            #canvas.itemconfig(arc, outline="lime")
        else:
            running = False
            ctypes.windll.kernel32.SetThreadExecutionState(ES_CONTINUOUS)
            label.config(text="❎ Stopped")
            btn_toggle.config(text="Start")
            #canvas.itemconfig(circle, outline="red")
            #canvas.itemconfig(arc, outline="red")

    btn_toggle = tk.Button(
        root,
        text="Start",
        width=10,
        command=toggle
    )

    canvas.create_window(
        120, 130,
        window=btn_toggle
    )

    progress_value = 0

    def update_progress():

        display_time = remaining_time if running else 0

        minutes = remaining_time // 60
        seconds = remaining_time % 60

        canvas.itemconfig(
            timer_text,
            text=f"{minutes:02d}:{seconds:02d}"
        )

        root.after(500, update_progress)

    animate_atom()   
    update_progress()   
    root.mainloop()


# --- Hotkeys ---
keyboard.add_hotkey("ctrl+alt+s", lambda: print("Hotkey Start") or globals().update(running=True))
keyboard.add_hotkey("ctrl+alt+x", lambda: print("Hotkey Stop") or globals().update(running=False))

# --- Threads ---
threading.Thread(target=track_activity, daemon=True).start()
threading.Thread(target=keep_awake, daemon=True).start()

# --- Launch GUI ---
start_gui()
import pyautogui
import time
import threading
import tkinter as tk

INTERVAL = 30  # seconds between activity

# Shared countdown variable
countdown = INTERVAL

# --- Background task ---
def keep_awake():
    global countdown
    while True:
        for i in range(INTERVAL, 0, -1):
            countdown = i
            time.sleep(1)

        pyautogui.press('shift')  # simulate activity
        countdown = INTERVAL


# --- UI ---
def start_ui():
    root = tk.Tk()
    root.title("Anti-Sleep Bot")
    root.geometry("220x120")
    root.attributes('-topmost', True)

    # Status label (blinking dot)
    status_label = tk.Label(root, text="🟢 Running", font=("Arial", 14))
    status_label.pack(pady=5)

    # Countdown label
    timer_label = tk.Label(root, text="", font=("Arial", 12))
    timer_label.pack()

    blinking = True

    # Update UI continuously
    def update_ui():
        nonlocal blinking

        # Blink effect
        blinking = not blinking
        dot = "🟢" if blinking else "⚪"
        status_label.config(text=f"{dot} Running")

        # Countdown display
        timer_label.config(text=f"Next activity in: {countdown}s")

        root.after(500, update_ui)  # refresh every 0.5 sec

    def stop():
        root.destroy()
        print("Stopped manually")
        exit()

    stop_btn = tk.Button(root, text="Stop", command=stop)
    stop_btn.pack(pady=8)

    update_ui()
    root.mainloop()


# --- Run both threads ---
threading.Thread(target=keep_awake, daemon=True).start()
start_ui()
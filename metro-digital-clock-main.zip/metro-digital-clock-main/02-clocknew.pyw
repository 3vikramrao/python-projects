
import sys, os
import tkinter as tk
from tkinter import messagebox
import time
from time import strftime

# ---------- Helpers ----------
def try_set_icon(win, icon_path='pixmeadefavicon.ico'):
    """Set icon only if on Windows and file exists; ignore errors."""
    if sys.platform.startswith('win') and os.path.exists(icon_path):
        try:
            win.iconbitmap(icon_path)
        except Exception:
            pass

def voltest():
    """Try to play a sound; fall back to a beep or print."""
    try:
        from playsound import playsound  # pip install playsound
        if os.path.exists('0451.wav'):
            playsound('0451.wav', block=False)
        else:
            raise FileNotFoundError("0451.wav not found")
    except Exception:
        try:
            import winsound  # Windows-only
            winsound.Beep(1000, 500)
        except Exception:
            print("Alarm! (Install playsound and add 0451.wav for sound.)")

# ---------- Main window ----------
root = tk.Tk()
root.title('Digital Clock')
root.geometry('680x415+100+100')
root.config(bg='Black')
try_set_icon(root)


title_label = tk.Label(
    root, text="DIGITAL CLOCK",
    font=('Digital-7 Mono', 15),
    bg='Black', fg='#50C9C3'
)
title_label.place(x=80, y=42)

# ---------- Alarm window ----------
def alarm():
    newWindow = tk.Toplevel(root)
    newWindow.title('Alarm')
    newWindow.geometry('430x385+800+100')
    newWindow.config(bg='Black')
    try_set_icon(newWindow)

    # Frame border (same as your canvases)
    c21 = tk.Canvas(newWindow, bg="#16222A", height=10, width=350, highlightthickness=0); c21.place(x=40, y=30)
    c22 = tk.Canvas(newWindow, bg="#16222A", height=10, width=350, highlightthickness=0); c22.place(x=40, y=345)
    c23 = tk.Canvas(newWindow, bg="#16222A", height=325, width=10, highlightthickness=0); c23.place(x=30, y=30)
    c24 = tk.Canvas(newWindow, bg="#16222A", height=325, width=10, highlightthickness=0); c24.place(x=390, y=30)

    lbl_alarm = tk.Label(newWindow, text='ALARM',
                         font=('DS-Digital', 45, 'bold'),
                         bg='#16222A', fg='#50C9C3', anchor='center')
    lbl_alarm.place(x=50, y=50, height=70, width=330)

    lbl_notice = tk.Label(newWindow, text='Enter "HOUR" in 24hr format',
                          font=('DS-Digital', 15),
                          bg='#16222A', fg='#f64f59', anchor='center')
    lbl_notice.place(x=50, y=130, height=45, width=330)

    lbl_alhour = tk.Label(newWindow, text='Hour ---->',
                          font=('DS-Digital', 15),
                          bg='#16222A', fg='#50C9C3', anchor='center')
    lbl_alhour.place(x=50, y=185, height=30, width=270)

    lbl_almin = tk.Label(newWindow, text='Minute --->',
                         font=('DS-Digital', 15),
                         bg='#16222A', fg='#50C9C3', anchor='center')
    lbl_almin.place(x=50, y=225, height=30, width=270)

    inputh = tk.Entry(newWindow, relief=tk.SUNKEN, bd=0,
                      font=('Digital-7 Mono', 15),
                      bg='#16222A', fg='#50C9C3', highlightthickness=0,
                      justify='center')
    inputh.place(x=330, y=185, width=50, height=30)

    inputm = tk.Entry(newWindow, relief=tk.SUNKEN, bd=0,
                      font=('Digital-7 Mono', 15),
                      bg='#16222A', fg='#50C9C3', highlightthickness=0,
                      justify='center')
    inputm.place(x=330, y=225, width=50, height=30)

    def setalarm():
        # Validate inputs
        try:
            ah = int(inputh.get())
            am = int(inputm.get())
            if not (0 <= ah <= 23 and 0 <= am <= 59):
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid time", "Enter valid 24-hour time: HH (0–23) and MM (0–59).")
            return

        # Disable button while alarm armed
        bset_al.config(state=tk.DISABLED)

        def check_alarm():
            now_h = int(strftime('%H'))
            now_m = int(strftime('%M'))
            if now_h == ah and now_m == am:
                voltest()
                messagebox.showinfo('Alarm', 'Alarm Time')
                bset_al.config(state=tk.NORMAL)
            else:
                newWindow.after(1000, check_alarm)

        check_alarm()

    bset_al = tk.Button(newWindow, text='SET ALARM', relief=tk.GROOVE,
                        activebackground='#f64f59', activeforeground='#16222A', bd=0,
                        font=('Digital-7 Mono', 15),
                        bg='#16222A', fg='#f64f59', highlightthickness=0,
                        command=setalarm)
    bset_al.place(x=50, y=265, height=30, width=330)

    bcancel = tk.Button(newWindow, text='CANCEL', relief=tk.GROOVE,
                        activebackground='#f64f59', activeforeground='#16222A', bd=0,
                        font=('Digital-7 Mono', 15),
                        bg='#16222A', fg='#f64f59', highlightthickness=0,
                        command=newWindow.destroy)
    bcancel.place(x=50, y=305, height=30, width=330)

# ---------- Time display + indicators ----------
def time_show():
    hour = strftime('%I:')
    mins = strftime('%M')
    sec  = strftime('%S')
    day  = strftime('%A')
    fulldate = strftime('%d-%b-%G')

    ampmholder = 'PM' if int(strftime('%H')) >= 12 else 'AM'

    lbl_hour.config(text=hour)
    lbl_min.config(text=mins)
    lbl_sec.config(text=sec)
    lbl_ampm.config(text=ampmholder)
    lbl_fulldate.config(text=fulldate)
    lbl_day.config(text=day)

    # Blink and bar animation on odd/even seconds
    if int(strftime('%S')) % 2 == 1:
        indicator2.config(bg="Black")
        indicator1.config(bg="#50C9C3")

        c5.itemconfig(in23, fill="#f64f59")
        c5.itemconfig(in24, fill="#50C9C3")
        c5.itemconfig(in25, fill="#f64f59")
        c5.itemconfig(in26, fill="#50C9C3")
        c5.itemconfig(in28, fill="#f64f59")
        c5.itemconfig(in29, fill="#50C9C3")
        c5.itemconfig(in30, fill="#f64f59")
        c5.itemconfig(in31, fill="#50C9C3")
        c5.itemconfig(in32, fill="#f64f59")
        c5.itemconfig(in33, fill="#50C9C3")
        c5.itemconfig(in34, fill="#f64f59")
        c5.itemconfig(in35, fill="#50C9C3")
        c5.itemconfig(in36, fill="#f64f59")
        c5.itemconfig(in37, fill="#50C9C3")
        c5.itemconfig(in38, fill="#f64f59")
        c5.itemconfig(in39, fill="#50C9C3")
        c5.itemconfig(in40, fill="#f64f59")

        c6.itemconfig(in41, fill="#f64f59")
        c6.itemconfig(in42, fill="#50C9C3")
        c6.itemconfig(in43, fill="#f64f59")
        c6.itemconfig(in44, fill="#50C9C3")
        c6.itemconfig(in45, fill="#f64f59")
        c6.itemconfig(in46, fill="#50C9C3")
        c6.itemconfig(in47, fill="#f64f59")
        c6.itemconfig(in48, fill="#50C9C3")
        c6.itemconfig(in49, fill="#f64f59")
        c6.itemconfig(in50, fill="#50C9C3")
        c6.itemconfig(in51, fill="#f64f59")
        c6.itemconfig(in52, fill="#50C9C3")
        c6.itemconfig(in53, fill="#f64f59")
        c6.itemconfig(in54, fill="#50C9C3")
        c6.itemconfig(in55, fill="#f64f59")
        c6.itemconfig(in56, fill="#50C9C3")
        c6.itemconfig(in57, fill="#f64f59")
    else:
        indicator1.config(bg="Black")
        indicator2.config(bg="#f64f59")

        c6.itemconfig(in41, fill="#50C9C3")
        c6.itemconfig(in42, fill="#f64f59")
        c6.itemconfig(in43, fill="#50C9C3")
        c6.itemconfig(in44, fill="#f64f59")
        c6.itemconfig(in45, fill="#50C9C3")
        c6.itemconfig(in46, fill="#f64f59")
        c6.itemconfig(in47, fill="#50C9C3")
        c6.itemconfig(in48, fill="#f64f59")
        c6.itemconfig(in49, fill="#50C9C3")
        c6.itemconfig(in50, fill="#f64f59")
        c6.itemconfig(in51, fill="#50C9C3")
        c6.itemconfig(in52, fill="#f64f59")
        c6.itemconfig(in53, fill="#50C9C3")
        c6.itemconfig(in54, fill="#f64f59")
        c6.itemconfig(in55, fill="#50C9C3")
        c6.itemconfig(in56, fill="#f64f59")
        c6.itemconfig(in57, fill="#50C9C3")

        c5.itemconfig(in23, fill="#50C9C3")
        c5.itemconfig(in24, fill="#f64f59")
        c5.itemconfig(in25, fill="#50C9C3")
        c5.itemconfig(in26, fill="#f64f59")
        c5.itemconfig(in28, fill="#50C9C3")
        c5.itemconfig(in29, fill="#f64f59")
        c5.itemconfig(in30, fill="#50C9C3")
        c5.itemconfig(in31, fill="#f64f59")
        c5.itemconfig(in32, fill="#50C9C3")
        c5.itemconfig(in33, fill="#f64f59")
        c5.itemconfig(in34, fill="#50C9C3")
        c5.itemconfig(in35, fill="#f64f59")
        c5.itemconfig(in36, fill="#50C9C3")
        c5.itemconfig(in37, fill="#f64f59")
        c5.itemconfig(in38, fill="#50C9C3")
        c5.itemconfig(in39, fill="#f64f59")
        c5.itemconfig(in40, fill="#50C9C3")

    # Schedule next tick
    root.after(1000, time_show)

# ---------- Labels ----------
lbl_hour = tk.Label(root, font=('DS-Digital', 120, 'bold'),
                    bg='#16222A', fg='#50C9C3', anchor='e')
lbl_hour.place(x=80, y=75, height=200, width=200)

lbl_min = tk.Label(root, font=('DS-Digital', 120, 'bold'),
                   bg='#16222A', fg='#50C9C3', anchor='e', padx=18)
lbl_min.place(x=290, y=75, height=200, width=200)

lbl_sec = tk.Label(root, font=('DS-Digital', 45, 'bold'),
                   bg='#16222A', fg='#50C9C3', anchor='e', padx=17)
lbl_sec.place(x=500, y=175, height=100, width=100)

lbl_ampm = tk.Label(root, font=('DS-Digital', 45, 'bold'),
                    bg='#16222A', fg='#50C9C3', anchor='center')
lbl_ampm.place(x=500, y=75, height=90, width=100)

lbl_fulldate = tk.Label(root, font=('DS-Digital', 20, 'bold'),
                        bg='#16222A', fg='#50C9C3', anchor='center')
lbl_fulldate.place(x=290, y=285, height=30, width=200)

lbl_day = tk.Label(root, font=('DS-Digital', 20, 'bold'),
                   bg='#16222A', fg='#50C9C3', anchor='center')
lbl_day.place(x=80, y=285, height=30, width=200)

lbl_12hrc = tk.Label(root, text="12 HOUR", font=('Digital-7 Mono', 15),
                     bg='Black', fg='#50C9C3')
lbl_12hrc.place(x=534, y=40)

# ---------- Boundaries ----------
c1 = tk.Canvas(root, bg="#16222A", height=10, width=540, highlightthickness=0); c1.place(x=70, y=365)
c2 = tk.Canvas(root, bg="#16222A", height=10, width=540, highlightthickness=0); c2.place(x=70, y=30)
c3 = tk.Canvas(root, bg="#16222A", height=345, width=10, highlightthickness=0); c3.place(x=60, y=30)
c4 = tk.Canvas(root, bg="#16222A", height=345, width=10, highlightthickness=0); c4.place(x=610, y=30)

# ---------- Buttons ----------
balarm = tk.Button(root, text='ALARM', relief=tk.GROOVE, activebackground='#f64f59',
                   activeforeground='#16222A', bd=0, font=('Digital-7 Mono', 15),
                   bg='#16222A', fg='#f64f59', highlightthickness=0, command=alarm)
balarm.place(x=80, y=325, height=30, width=200)

bvoltest = tk.Button(root, text='Volume Test', relief=tk.GROOVE, activebackground='#f64f59',
                     activeforeground='#16222A', bd=0, command=voltest,
                     font=('Digital-7 Mono', 15), bg='#16222A', fg='#f64f59', highlightthickness=0)
bvoltest.place(x=290, y=325, height=30, width=200)

bclose = tk.Button(root, text='CLOSE', relief=tk.GROOVE, activebackground='#f64f59',
                   activeforeground='#16222A', bd=0, command=root.destroy,
                   font=('Digital-7 Mono', 15), bg='#16222A', fg='#f64f59', highlightthickness=0)
bclose.place(x=500, y=325, height=30, width=100)

# ---------- Indicators ----------
indicator1 = tk.Canvas(root, bg="#50C9C3", height=7, width=95, highlightthickness=0); indicator1.place(x=290, y=50)
indicator2 = tk.Canvas(root, bg="#50C9C3", height=7, width=95, highlightthickness=0); indicator2.place(x=395, y=50)

c5 = tk.Canvas(root, bg="Black", height=15, width=100, highlightthickness=0)
in23 = c5.create_rectangle(3, 0, 5, 30, fill='Black', width=0)
in24 = c5.create_rectangle(9, 0, 11, 30, fill='Black', width=0)
in25 = c5.create_rectangle(15, 0, 17, 30, fill='Black', width=0)
in26 = c5.create_rectangle(21, 0, 23, 30, fill='Black', width=0)
in28 = c5.create_rectangle(27, 0, 29, 30, fill='Black', width=0)
in29 = c5.create_rectangle(33, 0, 35, 30, fill='Black', width=0)
in30 = c5.create_rectangle(39, 0, 41, 30, fill='Black', width=0)
in31 = c5.create_rectangle(45, 0, 47, 30, fill='Black', width=0)
in32 = c5.create_rectangle(51, 0, 53, 30, fill='Black', width=0)
in33 = c5.create_rectangle(57, 0, 59, 30, fill='Black', width=0)
in34 = c5.create_rectangle(63, 0, 65, 30, fill='Black', width=0)
in35 = c5.create_rectangle(69, 0, 71, 30, fill='Black', width=0)
in36 = c5.create_rectangle(75, 0, 77, 30, fill='Black', width=0)
in37 = c5.create_rectangle(81, 0, 83, 30, fill='Black', width=0)
in38 = c5.create_rectangle(87, 0, 89, 30, fill='Black', width=0)
in39 = c5.create_rectangle(93, 0, 95, 30, fill='Black', width=0)
in40 = c5.create_rectangle(99, 0, 101, 30, fill='Black', width=0)
c5.place(x=500, y=285)

c6 = tk.Canvas(root, bg='Black', height=15, width=100, highlightthickness=0)
in41 = c6.create_rectangle(0, 0, 2, 30, fill='Black', width=0)
in42 = c6.create_rectangle(6, 0, 8, 30, fill='Black', width=0)
in43 = c6.create_rectangle(12, 0, 14, 30, fill='Black', width=0)
in44 = c6.create_rectangle(18, 0, 20, 30, fill='Black', width=0)
in45 = c6.create_rectangle(24, 0, 26, 30, fill='Black', width=0)
in46 = c6.create_rectangle(30, 0, 32, 33, fill='Black', width=0)
in47 = c6.create_rectangle(36, 0, 38, 30, fill='Black', width=0)
in48 = c6.create_rectangle(42, 0, 44, 30, fill='Black', width=0)
in49 = c6.create_rectangle(48, 0, 50, 30, fill='Black', width=0)
in50 = c6.create_rectangle(54, 0, 56, 30, fill='Black', width=0)
in51 = c6.create_rectangle(60, 0, 62, 33, fill='Black', width=0)
in52 = c6.create_rectangle(66, 0, 68, 30, fill='Black', width=0)
in53 = c6.create_rectangle(72, 0, 74, 30, fill='Black', width=0)
in54 = c6.create_rectangle(78, 0, 80, 30, fill='Black', width=0)
in55 = c6.create_rectangle(84, 0, 86, 30, fill='Black', width=0)
in56 = c6.create_rectangle(90, 0, 92, 33, fill='Black', width=0)
in57 = c6.create_rectangle(96, 0, 98, 30, fill='Black', width=0)
c6.place(x=500, y=300)

# ---------- Stopwatch ----------
def stopwatch_window():
    win = tk.Toplevel(root)
    win.title('Stopwatch')
    win.geometry('430x385+820+100')
    win.config(bg='Black')
    try_set_icon(win)

    # Border
    tk.Canvas(win, bg="#16222A", height=10, width=350, highlightthickness=0).place(x=40, y=30)
    tk.Canvas(win, bg="#16222A", height=10, width=350, highlightthickness=0).place(x=40, y=345)
    tk.Canvas(win, bg="#16222A", height=325, width=10, highlightthickness=0).place(x=30, y=30)
    tk.Canvas(win, bg="#16222A", height=325, width=10, highlightthickness=0).place(x=390, y=30)

    lbl_header = tk.Label(win, text='STOPWATCH', font=('DS-Digital', 45, 'bold'),
                          bg='#16222A', fg='#50C9C3')
    lbl_header.place(x=50, y=50, height=70, width=330)

    lbl_time = tk.Label(win, text='00:00:00.00', font=('DS-Digital', 40, 'bold'),
                        bg='#16222A', fg='#50C9C3')
    lbl_time.place(x=50, y=150, height=70, width=330)

    state = {'running': False, 'start': 0, 'elapsed': 0}

    def update():
        if state['running']:
            now = time.time()
            total = state['elapsed'] + (now - state['start'])
            hrs = int(total // 3600)
            mins = int((total % 3600) // 60)
            secs = total % 60
            lbl_time.config(text=f"{hrs:02d}:{mins:02d}:{secs:05.2f}")
        win.after(50, update)
    update()

    def start():
        if not state['running']:
            state['start'] = time.time()
            state['running'] = True

    def pause():
        if state['running']:
            state['elapsed'] += time.time() - state['start']
            state['running'] = False

    def reset():
        state['running'] = False
        state['start'] = 0
        state['elapsed'] = 0
        lbl_time.config(text='00:00:00.00')

    tk.Button(win, text='Start', font=('Digital-7 Mono', 15), bg='#16222A', fg='#50C9C3', command=start).place(x=50,  y=260, width=100, height=35)
    tk.Button(win, text='Pause', font=('Digital-7 Mono', 15), bg='#16222A', fg='#f64f59', command=pause).place(x=160, y=260, width=100, height=35)
    tk.Button(win, text='Reset', font=('Digital-7 Mono', 15), bg='#16222A', fg='yellow', command=reset).place(x=270, y=260, width=110, height=35)

    tk.Button(win, text='Close', font=('Digital-7 Mono', 15), bg='#16222A', fg='#f64f59', command=win.destroy).place(x=50, y=305, width=330, height=30)

# ---------- Timer ----------
def timer_window():
    win = tk.Toplevel(root)
    win.title('Timer')
    win.geometry('430x385+820+100')
    win.config(bg='Black')
    try_set_icon(win)

    # Border
    tk.Canvas(win, bg="#16222A", height=10, width=350, highlightthickness=0).place(x=40, y=30)
    tk.Canvas(win, bg="#16222A", height=10, width=350, highlightthickness=0).place(x=40, y=345)
    tk.Canvas(win, bg="#16222A", height=325, width=10, highlightthickness=0).place(x=30, y=30)
    tk.Canvas(win, bg="#16222A", height=325, width=10, highlightthickness=0).place(x=390, y=30)

    tk.Label(win, text='TIMER', font=('DS-Digital', 45, 'bold'), bg='#16222A', fg='#50C9C3').place(x=50, y=50, height=70, width=330)

    # Inputs
    e_h = tk.Entry(win, font=('Digital-7 Mono', 20), bg='#16222A', fg='#50C9C3', justify='center')
    e_m = tk.Entry(win, font=('Digital-7 Mono', 20), bg='#16222A', fg='#50C9C3', justify='center')
    e_s = tk.Entry(win, font=('Digital-7 Mono', 20), bg='#16222A', fg='#50C9C3', justify='center')
    e_h.place(x=50, y=150, width=100, height=40)
    e_m.place(x=165, y=150, width=100, height=40)
    e_s.place(x=280, y=150, width=100, height=40)

    tk.Label(win, text='H', bg='Black', fg='#50C9C3').place(x=90,  y=195)
    tk.Label(win, text='M', bg='Black', fg='#50C9C3').place(x=205, y=195)
    tk.Label(win, text='S', bg='Black', fg='#50C9C3').place(x=320, y=195)

    lbl_display = tk.Label(win, text='00:00:00', font=('DS-Digital', 40, 'bold'), bg='#16222A', fg='#50C9C3')
    lbl_display.place(x=50, y=230, width=330, height=50)

    state = {'total': 0, 'running': False}

    def set_timer():
        try:
            h = int(e_h.get() or 0)
            m = int(e_m.get() or 0)
            s = int(e_s.get() or 0)
            total = h*3600 + m*60 + s
            if total <= 0: raise ValueError
            state['total'] = total
            update_display()
        except:
            messagebox.showerror('Error', 'Enter valid time.')

    def update_display():
        t = state['total']
        h = t // 3600
        m = (t % 3600) // 60
        s = t % 60
        lbl_display.config(text=f"{h:02d}:{m:02d}:{s:02d}")

    def tick():
        if state['running'] and state['total'] > 0:
            state['total'] -= 1
            update_display()
            if state['total'] == 0:
                voltest()
                messagebox.showinfo('Timer', "Time's Up!")
                state['running'] = False
            else:
                win.after(1000, tick)

    def start():
        if state['total'] > 0 and not state['running']:
            state['running'] = True
            tick()

    def pause():
        state['running'] = False

    def reset():
        state['running'] = False
        state['total'] = 0
        lbl_display.config(text='00:00:00')

    tk.Button(win, text='Set Timer', font=('Digital-7 Mono', 15), bg='#16222A', fg='#50C9C3', command=set_timer).place(x=50, y=300, width=100, height=35)
    tk.Button(win, text='Start', font=('Digital-7 Mono', 15), bg='#16222A', fg='#50C9C3', command=start).place(x=160, y=300, width=100, height=35)
    tk.Button(win, text='Pause', font=('Digital-7 Mono', 15), bg='#16222A', fg='#f64f59', command=pause).place(x=270, y=300, width=100, height=35)
    tk.Button(win, text='Reset', font=('Digital-7 Mono', 15), bg='#16222A', fg='yellow', command=reset).place(x=50, y=340, width=330, height=30)

# ---------- Pomodoro ----------
def pomodoro_window():
    win = tk.Toplevel(root)
    win.title('Pomodoro')
    win.geometry('430x385+820+100')
    win.config(bg='Black')
    try_set_icon(win)

    tk.Label(
        win,
        text='POMODORO',
        font=('DS-Digital', 45, 'bold'),
        bg='#16222A',
        fg='#50C9C3'
    ).place(x=50, y=50, width=330, height=70)

    lbl = tk.Label(
        win,
        text='25:00',
        font=('DS-Digital', 60, 'bold'),
        bg='#16222A',
        fg='#50C9C3'
    )
    lbl.place(x=50, y=140, width=330, height=80)

    state = {'time': 1500, 'running': False}

    def update():
        m = state['time'] // 60
        s = state['time'] % 60
        lbl.config(text=f"{m:02d}:{s:02d}")

    def tick():
        if state['running'] and state['time'] > 0:
            state['time'] -= 1
            update()

            if state['time'] == 0:
                voltest()
                messagebox.showinfo('Pomodoro', 'Work session complete! Take a 5 minute break.')
                state['time'] = 300
                state['running'] = True
                tick()
                state['running'] = False
            else:
                win.after(1000, tick)

    def start():
        if not state['running']:
            state['running'] = True
            tick()

    def pause():
        state['running'] = False

    def reset():
        state['running'] = False
        state['time'] = 1500
        update()

    tk.Button(win, text='Start', command=start,
              bg='#16222A', fg='#50C9C3').place(x=50, y=270, width=100)

    tk.Button(win, text='Pause', command=pause,
              bg='#16222A', fg='#f64f59').place(x=165, y=270, width=100)

    tk.Button(win, text='Reset', command=reset,
              bg='#16222A', fg='yellow').place(x=280, y=270, width=100)

    update()

# ---------- Color Change ----------
def change_color(c):
    for w in [lbl_hour, lbl_min, lbl_sec, lbl_ampm, lbl_fulldate, lbl_day]:
        w.config(fg=c)
# ---------- Menu Bar ----------
menubar = tk.Menu(root)
root.config(menu=menubar)

menu_main = tk.Menu(menubar, tearoff=0)
menubar.add_cascade(label='Menu', menu=menu_main)

color_menu = tk.Menu(menu_main, tearoff=0)
# stopwatch_menu = tk.Menu(menu_main, tearoff=0)
# timer_menu = tk.Menu(menu_main, tearoff=0)
menu_main.add_cascade(label='Color', menu=color_menu)
color_menu.add_command(label='Neon Blue', command=lambda: change_color('#50C9C3'))
color_menu.add_command(label='Bright Green', command=lambda: change_color('#00FF00'))
color_menu.add_command(label='Red',        command=lambda: change_color('#FF0000'))
color_menu.add_command(label='Yellow',     command=lambda: change_color('#FFFF00'))

stopwatch_menu = tk.Menu(menu_main, tearoff=0)
timer_menu = tk.Menu(menu_main, tearoff=0)
pomodoro_menu = tk.Menu(menu_main, tearoff=0)

menu_main.add_command(label='Stopwatch', command=stopwatch_window)
menu_main.add_command(label='Timer', command=timer_window)
menu_main.add_command(label='Pomodoro', command=pomodoro_window)

menu_main.add_separator()
menu_main.add_command(label='Exit', command=root.destroy)

help_menu = tk.Menu(menubar, tearoff=0)
menubar.add_cascade(label='Help', menu=help_menu)
help_menu.add_command(label='About', command=lambda: messagebox.showinfo('About', 'Digital Clock with Alarm, Stopwatch, Timer Created for Trivikram Rao'))

# ---------- Start the clock ----------
time_show()
root.mainloop()

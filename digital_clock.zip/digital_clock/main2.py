
import tkinter as tk
from time import strftime

root = tk.Tk()
root.title('Digital Clock')

label = tk.Label(
    root,
    anchor='center',
    font=("ds-digital", 80),   # falls back if not installed
    background="black",
    foreground="lime"
)
label.pack(fill=tk.BOTH, expand=True)

def tick():
    label.config(text=strftime('%H:%M:%S %p'))  # 24h with AM/PM; use %I for 12h
    root.after(1000, tick)

tick()
root.mainloop()

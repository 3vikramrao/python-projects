
import tkinter as tk
from tkinter import messagebox
from time import strftime
import sys

# ---------- Diagnostics ----------
print("Starting Digital Clock with menu...")
print("Python:", sys.version)

# ---------- App setup ----------
root = tk.Tk()
root.title("Digital Clock (Menu Demo)")

# Label (use a safe, built-in font first)
BG = "black"
DEFAULT_COLOR_NAME = "Red"
COLOR_MAP = {
    "Neon Blue": "#00FFFF",
    "Lime":      "#00FF00",
    "Red":       "#FF3333",
    "Yellow":    "#FFFF33",
}

current_color = tk.StringVar(value=DEFAULT_COLOR_NAME)

label = tk.Label(
    root,
    anchor="center",
    font=("ds-digital", 100, "bold"),  # safe fallback font
    background=BG,
    foreground=COLOR_MAP[current_color.get()],
)
label.pack(fill=tk.BOTH, expand=True)

# ---------- Functions ----------
def set_color(name: str):
    if name in COLOR_MAP:
        current_color.set(name)
        label.config(fg=COLOR_MAP[name])
        print(f"Color set to: {name} -> {COLOR_MAP[name]}")
    else:
        print(f"[WARN] Unknown color '{name}'")

def tick():
    try:
        label.config(text=strftime("%H:%M:%S %p"))  # 24h with AM/PM; use %I for 12h
    except Exception as e:
        print("tick() error:", e)
    root.after(1000, tick)

def on_about():
    messagebox.showinfo(
        "About",
        "Digital Clock\n\n"
        "File → Color: change number color (Neon Blue, Lime, Red, Yellow)\n"
        "File → Exit: quit the app\n"
        "Help → About: this dialog\n\n"
        "This app is designed using co-pilot by Trivikram Rao"
    )

def on_exit():
    root.destroy()

# ---------- Menu ----------
menubar = tk.Menu(root)

file_menu = tk.Menu(menubar, tearoff=0)
color_menu = tk.Menu(file_menu, tearoff=0)

for name in COLOR_MAP.keys():
    # Radiobutton so current selection is checked
    color_menu.add_radiobutton(
        label=name,
        variable=current_color,
        value=name,
        command=lambda n=name: set_color(n)
    )

file_menu.add_cascade(label="Color", menu=color_menu)
file_menu.add_separator()
file_menu.add_command(label="Exit", command=on_exit)

help_menu = tk.Menu(menubar, tearoff=0)
help_menu.add_command(label="About", command=on_about)

menubar.add_cascade(label="File", menu=file_menu)
menubar.add_cascade(label="Help", menu=help_menu)

root.config(menu=menubar)

# Optional shortcuts for Exit
root.bind_all("<Control-q>", lambda e: on_exit())
root.bind_all("<Command-q>", lambda e: on_exit())  # macOS

# ---------- Start ----------
# Show a tiny startup confirmation
try:
    root.after(100, lambda: messagebox.showinfo("Status", "Clock UI started."))
except Exception as e:
    print("Startup messagebox error:", e)

tick()
print("Entering mainloop()...")
root.mainloop()
print("Exited mainloop().")


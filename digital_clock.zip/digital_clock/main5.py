
import tkinter as tk
from tkinter import messagebox
from time import strftime

# ---------------- App setup ----------------
root = tk.Tk()
root.title("Digital Clock")

# Fix the overall window size so it doesn't change.
WINDOW_W, WINDOW_H = 800, 250
root.geometry(f"{WINDOW_W}x{WINDOW_H}")
root.minsize(WINDOW_W, WINDOW_H)
root.maxsize(WINDOW_W, WINDOW_H)  # comment this out if you want resizable window

# A container that fills the window but does NOT resize to content.
container = tk.Frame(root, bg="black")
container.pack(fill=tk.BOTH, expand=True)
container.pack_propagate(False)  # prevent child (label) from changing container size

# ---------------- Colors & font ----------------
BG = "black"
COLOR_MAP = {
    "Neon Blue": "#00FFFF",
    "Lime":      "#00FF00",
    "Red":       "#FF3333",
    "Yellow":    "#FFFF33",
}
current_color = tk.StringVar(value="Red")

def best_font():
    """
    Try a monospaced digital font if installed; otherwise a monospaced system font.
    """
    try:
        test = tk.Label(container, font=("Digital-7 Mono", 10))
        test.destroy()
        return ("ds-digital", 80, "bold")   # adjust to taste
    except tk.TclError:
        return ("Courier New", 84, "bold")

label = tk.Label(
    container,
    font=best_font(),
    bg=BG,
    fg=COLOR_MAP[current_color.get()],
)
label.place(relx=0.5, rely=0.5, anchor="center")

# ---------------- Time format toggle ----------------
# True  => 12-hour with AM/PM
# False => 24-hour
use_12h = tk.BooleanVar(value=True)

def current_time_text():
    # Build the time string based on the toggle
    if use_12h.get():
        # Add a leading space to stabilize width across AM/PM in some fonts (optional)
        return strftime("%I:%M:%S %p")  # e.g., 08:05:33 PM
    else:
        return strftime("%H:%M:%S")     # e.g., 20:05:33

# ---------------- Menu actions ----------------
def set_color(name: str):
    if name in COLOR_MAP:
        current_color.set(name)
        label.config(fg=COLOR_MAP[name])

def on_about():
    messagebox.showinfo(
        "About",
        "Digital Clock\n\n"
        "• File → Color: change the number color (Neon Blue, Lime, Red, Yellow)\n"
        "• View → 12‑Hour Clock: toggle 12h/24h format\n"
        "• File → Exit: quit the app\n"
        "• Help → About: this dialog\n\n"
        "Tip: Use a monospaced digital font (e.g., 'Digital-7 Mono') to keep width stable."
    )

def on_exit():
    root.destroy()

def toggle_12h():
    # Just trigger an immediate refresh so the format change is visible right away
    label.config(text=current_time_text())

# ---------------- Menus ----------------
menubar = tk.Menu(root)

# File menu with Color submenu and Exit
file_menu = tk.Menu(menubar, tearoff=0)
color_menu = tk.Menu(file_menu, tearoff=0)
for name in COLOR_MAP.keys():
    color_menu.add_radiobutton(
        label=name,
        variable=current_color,
        value=name,
        command=lambda n=name: set_color(n)
    )
file_menu.add_cascade(label="Color", menu=color_menu)
file_menu.add_separator()
file_menu.add_command(label="Exit", command=on_exit)

# View menu with 12h/24h toggle
view_menu = tk.Menu(menubar, tearoff=0)
view_menu.add_checkbutton(
    label="12‑Hour Clock",
    variable=use_12h,
    command=toggle_12h
)

# Help menu
help_menu = tk.Menu(menubar, tearoff=0)
help_menu.add_command(label="About", command=on_about)

menubar.add_cascade(label="File", menu=file_menu)
menubar.add_cascade(label="View", menu=view_menu)
menubar.add_cascade(label="Help", menu=help_menu)
root.config(menu=menubar)

# Optional: keyboard shortcut for Exit
root.bind_all("<Control-q>", lambda e: on_exit())
root.bind_all("<Command-q>", lambda e: on_exit())  # macOS

# ---------------- Clock update ----------------
def tick():
    label.config(text=current_time_text())
    root.after(1000, tick)

tick()
root.mainloop()


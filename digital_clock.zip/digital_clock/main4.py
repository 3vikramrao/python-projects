
import tkinter as tk
from tkinter import messagebox
from time import strftime

# ---------------- App setup ----------------
root = tk.Tk()
root.title("Digital Clock")

# Fix the overall window size so it doesn't change.
# You can tweak these values for your screen, font, and DPI.
WINDOW_W, WINDOW_H = 800, 250
root.geometry(f"{WINDOW_W}x{WINDOW_H}")
root.minsize(WINDOW_W, WINDOW_H)
root.maxsize(WINDOW_W, WINDOW_H)  # comment this out if you want resizable window

# A container that fills the window but does NOT resize to content.
container = tk.Frame(root, bg="black")
container.pack(fill=tk.BOTH, expand=True)
container.pack_propagate(False)  # prevent child (label) from changing container size

# ---------------- Colors & font ----------------
BG = "black"
COLOR_MAP = {
    "Neon Blue": "#00FFFF",
    "Lime":      "#00FF00",
    "Red":       "#FF3333",
    "Yellow":    "#FFFF33",
}
current_color = tk.StringVar(value="Red")

def best_font():
    """
    Try a monospaced digital font if you have it installed.
    Falls back to a monospaced system font to keep width consistent.
    """
    try:
        # This will not crash even if font missing; but to be safe:
        test = tk.Label(container, font=("Digital-7 Mono", 10))
        test.destroy()
        return ("Digital-7 Mono", 120)   # adjust size to your liking
    except tk.TclError:
        # Guaranteed monospaced fallback
        return ("Courier New", 84, "bold")

# ---------------- Label (fixed area, centered) ----------------
label = tk.Label(
    container,
    font=best_font(),
    bg=BG,
    fg=COLOR_MAP[current_color.get()],
)

# Place the label centered inside the fixed-size container.
# The container's size is driven by the window geometry above.
label.place(relx=0.5, rely=0.5, anchor="center")

# Optional: if you want a guaranteed text width, you can pad with spaces.
# For example, if you fear AM/PM width differences in some fonts:
# label.config(text=" 00:00:00 AM ")

# ---------------- Menu ----------------
def set_color(name: str):
    if name in COLOR_MAP:
        current_color.set(name)
        label.config(fg=COLOR_MAP[name])

def on_about():
    messagebox.showinfo(
        "About",
        "Digital Clock\n\n"
        "File → Color to change the number color (Neon Blue, Lime, Red, Yellow)\n"
        "Help → About for this dialog.\n\n"
        "Tip: Use a monospaced digital font (e.g., 'Digital-7 Mono') to keep width stable."
    )

def on_exit():
    root.destroy()

menubar = tk.Menu(root)

file_menu = tk.Menu(menubar, tearoff=0)
color_menu = tk.Menu(file_menu, tearoff=0)

for name in COLOR_MAP.keys():
    color_menu.add_radiobutton(
        label=name,
        variable=current_color,
        value=name,
        command=lambda n=name: set_color(n)
    )

file_menu.add_cascade(label="Color", menu=color_menu)
file_menu.add_separator()
file_menu.add_command(label="Exit", command=on_exit)

help_menu = tk.Menu(menubar, tearoff=0)
help_menu.add_command(label="About", command=on_about)

menubar.add_cascade(label="File", menu=file_menu)
menubar.add_cascade(label="Help", menu=help_menu)
root.config(menu=menubar)

# ---------------- Clock update ----------------
def tick():
    # If you prefer 12-hour display, use '%I:%M:%S %p' instead.
    label.config(text=strftime('%H:%M:%S %p'))
    root.after(1000, tick)

tick()
root.mainloop()

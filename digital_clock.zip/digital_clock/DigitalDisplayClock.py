
import tkinter as tk
from tkinter import messagebox
from time import strftime

# --- App setup ---
root = tk.Tk()
root.title('Digital Clock')

# --- Theme (background stays black, foreground is changeable) ---
BG = "black"

# Neon-like color map
COLOR_MAP = {
    "Neon Blue": "#00FFFF",  # aqua cyan
    "Lime":      "#00FF00",
    "Red":       "#FF3333",
    "Yellow":    "#FFFF33",
}

# Default color
current_color = tk.StringVar(value="Red")

label = tk.Label(
    root,
    anchor='center',
    font=("ds-digital", 80),   # falls back if not installed
    background=BG,
    foreground=COLOR_MAP[current_color.get()],
)
label.pack(fill=tk.BOTH, expand=True)

# --- Functions ---
def set_color(name: str):
    """Update the label fg color based on menu selection."""
    if name in COLOR_MAP:
        current_color.set(name)
        label.config(fg=COLOR_MAP[name])

def tick():
    label.config(text=strftime('%H:%M:%S %p'))  # 24h with AM/PM; use %I for 12h
    root.after(1000, tick)

def on_about():
    messagebox.showinfo(
        "About",
        "Digital Clock\n\n"
        "Features:\n"
        "• File → Color: change the number color (Neon Blue, Lime, Red, Yellow)\n"
        "• File → Exit: quit the app\n"
        "• Help → About: this dialog\n\n"
        "Tip: Install the 'DS-Digital' font for a true digital look."
    )

def on_exit():
    root.destroy()

# --- Menus ---
menubar = tk.Menu(root)

# File menu with Color submenu
file_menu = tk.Menu(menubar, tearoff=0)
color_menu = tk.Menu(file_menu, tearoff=0)

# Add radiobutton items so the chosen color is checked
